//
//  ViewController.swift
//  ReadingApp
//
//  Created by John Doll on 8/30/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

