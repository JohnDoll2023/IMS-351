//
//  DTCollectionViewCell.swift
//  DailyTennisProject
//
//  Created by John Doll on 9/22/22.
//

import UIKit

class DTCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    
}
