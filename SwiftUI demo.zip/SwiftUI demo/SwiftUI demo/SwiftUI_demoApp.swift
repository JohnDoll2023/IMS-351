//
//  SwiftUI_demoApp.swift
//  SwiftUI demo
//
//  Created by John Doll on 10/25/22.
//

import SwiftUI

@main
struct SwiftUI_demoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
